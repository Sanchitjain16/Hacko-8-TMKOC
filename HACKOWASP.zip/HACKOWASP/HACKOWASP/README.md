# Battle of Tech - Round 1 - Div-A-Div

## Rulebook & Demo: https://link.leadthapar.com/round-1